# TODO
# Make a master list of enums which are used in the data files
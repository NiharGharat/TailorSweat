# TailorSweat

# Exercise Naming convention
1. All small letters
2. Underscore seperated
3. Singluar - leg_press, tricep_extension

# Assumptions
1. Legs are not split in quads, calves, hamstrings, etc. - rather its just legs

# Information about data
## 1 exercise.csv

1. 
2. 



## 2 workouts.csv
1. 
2. 


## 3 metadata_exercise.csv
1. Has the numeric value mappings of muscle group


## 4 user.csv
1. 
2. 


## 5 exercise_derived.csv
1. 
2. 

## 6 workout_derived.csv
1. 
2. 